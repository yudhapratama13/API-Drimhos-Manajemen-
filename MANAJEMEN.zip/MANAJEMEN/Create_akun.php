<?php 

	include('config.php');

	$nama_lengkap   = $_POST['nama_lengkap'];
	$nama_panggilan = $_POST['nama_panggilan'];
	$no_tlp 		= $_POST['no_tlp'];
	$email 		    = $_POST['email'];
	$password 		= $_POST['password'];

	class emp{}

	if (empty($nama_lengkap) || empty($nama_panggilan) || empty($no_tlp) || empty($email) || empty($password)) {
		$response = new emp();
		$response->success = 0;
		$response->message = 'Kolom Tidak Boleh Kosong';
		die(json_encode($response));
	}
	else{
		$query = mysql_query("INSERT INTO users VALUES ('', '$nama_lengkap', '$nama_panggilan', '$no_tlp', '$email', '$password', '', 'costumer servis') ");

		if ($query) {
			$response = new emp();
			$response->success = 1;
			$response->message = 'Akun Berhasil di Simpan';
			die(json_encode($response));
		}
		else{
			$response = new emp();
			$response->success = 0;
			$response->message = 'Akun Gagal di Simpan';
			die(json_encode($response));
		}
	}

?>