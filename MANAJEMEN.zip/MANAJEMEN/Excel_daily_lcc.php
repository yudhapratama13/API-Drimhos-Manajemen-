<?php

include('Config_lcc_daily_excel.php');

$date = date("Y-m-d");

 ob_get_clean();
 $filename = "Recap_Daily_Leads_List_".$date.".xml";
 header("Content-Type: application/vnd.ms-excel");
 header('Content-Disposition: attachment; filename='.$filename);


?>

<!DOCTYPE html>
            <!-- START @PAGE CONTENT -->
            <section id="page-content">
                <!-- Start page header -->
                <div id="tour-11" class="header-content">
                    <h2><i class="fa fa-home">
                        
                    </i>LCC
                    <span>Daily Leads List <?php echo $date;?></span> </h2>
                    <div class="breadcrumb-wrapper hidden-xs">
                    </div>
                </div>
                <!-- /.header-content -->
                <!--/ End page header -->

                <!-- Start body content -->
                <div class="body-content animated fadeIn">

                    <div id="tour-12" class="row">
                    </div>

                    <div class="row">
                    </div>

                    <!-- /.row -->
                    <div class="row">
                    <div class="col-md-12">

                <div class="panel rounded shadow">
                <div class="panel-body no-padding">

<!-- TABEL KEDUA -->
                <div class="panel-body">

                <table id="datatable-dom" class="table table-striped table-lilac" border="1px" bordercolor="black">
                <thead>

                <tr>
                    <th data-hide="phone,tablet"  class="text-center" rowspan="2" style="background-color: #01B050; color: #000;"> Nama CS</th>
                    <th data-hide="phone,tablet"  class="text-center" colspan="3" style="background-color: #C0504D; color: #000;"> LEADS </th>
                    <th data-hide="phone,tablet"  class="text-center" colspan="3" style="background-color: #F79646; color: #000;"> CLOSING (POIN) </th>
                    <th data-hide="phone,tablet"  class="text-center" colspan="3" style="background-color: #FF0101; color: #000;"> CONVERSION </th>
                </tr>

                <tr>
                    <th data-hide="phone,tablet"  class="text-center" style="background-color: #8DB4E2; color: #000;"> H </th>
                    <th data-hide="phone,tablet"  class="text-center" style="background-color: #92D050; color: #000;"> M </th>
                    <th data-hide="phone,tablet"  class="text-center" style="background-color: #FFFF01; color: #000;"> T </th>

                    <th data-hide="phone,tablet"  class="text-center" style="background-color: #8DB4E2; color: #000;"> H </th>
                    <th data-hide="phone,tablet"  class="text-center" style="background-color: #92D050; color: #000;"> M </th>
                    <th data-hide="phone,tablet"  class="text-center" style="background-color: #FFFF01; color: #000;"> T </th>

                    <th data-hide="phone,tablet"  class="text-center" style="background-color: #8DB4E2; color: #000;"> H </th>
                    <th data-hide="phone,tablet"  class="text-center" style="background-color: #92D050; color: #000;"> M </th>
                    <th data-hide="phone,tablet"  class="text-center" style="background-color: #FFFF01; color: #000;"> T </th>
                </tr>

                </thead>

                <tbody>

                <?php

            $query_user = mysql_query("SELECT * FROM users WHERE rule_user = 'costumer servis' ORDER BY user_name ASC");

            $leads_amount_d_jum = 0;
            $leads_amount_w_jum = 0;
            $leads_m_jum = 0;

            $point_jumlah_tot_jum = 0;
            $point_jum_tot_w = 0;
            $point_jum_ = 0;

            $conversion_hari_1_jum = 0;
            $conversion_mount_1_jum = 0;
            $conversion_week_1_jum = 0;

            while ($baris_user = mysql_fetch_array($query_user)) {
                $user_id = $baris_user['user_id'];
                $user_name = $baris_user['user_name'];

                // =================== mengambil data perhari ==============

                $date_today = date("Y-m-d");
                $query_leads = mysql_query("SELECT * FROM leads WHERE user_id = '$user_id' AND leads_date = '$date_today'");
                $baris_leads = mysql_fetch_array($query_leads);
                $leads_amount_d = $baris_leads['leads_amount'];

                if (true == empty($leads_amount_d)) {
                    $leads_amount_d = 0;
                } 
                
                // ================== mengambil data leads per minggu ===========
                
                 // bulan ini
                 $mount = date("m");
                 // tangal hari ini
                 $hari_ini = date("Y-m-d");               
                 // mengecek tanggal
                 $hari_bulan = date('j');

                 $bulan_start = $mount;

                 $tahun_start = date("Y");

                 for ($i=1; $i <= 8; $i++) { 
                 $hari_pada_bulan =  $tahun_start."-".$bulan_start."-0".$i;

                 // echo "====== </br>";

                 // echo $hari_pada_bulan; echo "<-- hari yang diperiksa </br>";
                 
                 $date=date_create($hari_pada_bulan);

                 $variabel_sabtu = date_format($date,"N"); 

                 // echo  $variabel_sabtu; echo "<-- angka sabtu </br>"; 

                 $tanggal_sabtu_pertama = $i;    

                    if ($variabel_sabtu == 6) {

                        $hari_akhir = $hari_pada_bulan;
                        // echo  $hari_akhir; echo "<-- angka hari akhir </br> ====== "; 

                        $i = 8;
                    }
                  }

                // jika tanggal hari ini berada diantara tanggal 01 dan sabu pertama
                    // maka tanggal akhir adalah sabut pertama
                    // jika tidak rumus dialihkan

                if ($hari_bulan <= $tanggal_sabtu_pertama) {

                    // awal minggu pertama pada satu bulan adalah tanggal 01
                    $bulan_start = date("m");
                    $tahun_start = date("Y");
                    $hari_pertama =  $tahun_start."-".$bulan_start."-01";
                    $hari_akhir;
                
                } else {

                    // akhir dan pertengahan bulan
                    $hari_akhir = date("Y-m-d");
                    // echo $hari_ini." <-- hari ini </br>";

                    $nomer_hari = date('N');
                    // echo $nomer_hari." <-- nomer hari </br>";

                    $kurang_1 = $nomer_hari - 1 ;
                    $jumlah_hari =  $kurang_1." days";

                    $date = date_create($hari_ini);
                    date_sub($date,date_interval_create_from_date_string($jumlah_hari));
                    $hari_pertama = date_format($date,"Y-m-d");

                }

                // echo "</br>";
                // echo $hari_awal; echo "<-- hari awal </br>";
                // echo $hari_ini; echo "<-- hari ini </br>";

                $leads_amount_w_tot = 0;
                $query_leads_w = mysql_query ("SELECT * FROM leads 
                    WHERE user_id = '$user_id' 
                    AND leads_date BETWEEN '$hari_pertama' AND '$hari_akhir'");

                while ($baris_leads_w = mysql_fetch_array($query_leads_w)) {
                    $leads_amount_w = $baris_leads_w['leads_amount'];

                    $leads_amount_w_s = $leads_amount_w_tot + $leads_amount_w;
                    $leads_amount_w_tot = $leads_amount_w_s;
                }

                if (true == empty($leads_amount_w_tot)) {
                     $leads_amount_w_tot = 0;
                } 


                // ================== mengambil data leads per bulan ============

                $query_leads_m = mysql_query("SELECT *  FROM leads 
                    WHERE user_id = '$user_id' 
                    AND month(leads_date)='$mount'");

                $leads_amount_m_tot = 0;
                while ($baris_leads_m = mysql_fetch_array($query_leads_m)) {
                    $leads_amount_m = $baris_leads_m['leads_amount'];

                    $leads_amount_m_s = $leads_amount_m_tot + $leads_amount_m;
                    $leads_amount_m_tot = $leads_amount_m_s;

                    }

                if (true == empty($leads_amount_m_tot)) {
                    $leads_amount_m_tot = 0;
                }                           

                // ================== mengambil data poin hari ============   

                $date_today = date("Y-m-d");

                $bagianWhere_w = "user_id = '$user_id' AND transaction_date = '$date_today'";
                $nama_barang_query = mysql_query ("SELECT 

                transactions.transaction_id, 
                transactions.transaction_date, 
                transactions.user_id, 
                transactions.customer_id, 
                transactions.shipping_name, 
                transactions.shipping_fee, 
                transactions.total_price, 
                transactions.payment, 
                transactions.receipt_number, 
                transactions.transaction_status,

                transactions_amount.transactions_amount_id, 
                transactions_amount.transaction_id, 
                transactions_amount.product_id, 
                transactions_amount.transaction_amount,

                products.product_id, 
                products.product_title_general, 
                products.product_title_for_recap, 
                products.product_initial_for_label, 
                products.product_base_price, 
                products.product_weight, 
                products.product_point, 
                products.product_status, 
                products.product_amount

               FROM transactions JOIN transactions_amount ON transactions.transaction_id = transactions_amount.transaction_id RIGHT JOIN products ON transactions_amount.product_id = products.product_id WHERE ".$bagianWhere_w);

                $point_jumlah_tot = 0;
                while ($baris_nama_barang = mysql_fetch_array($nama_barang_query)) {

                $amo_id = $baris_nama_barang['transaction_amount'];
                $point_id = $baris_nama_barang['product_point'];

                $point_jumlah = $amo_id * $point_id;

                $point_jumlah_s = $point_jumlah_tot + $point_jumlah;
                $point_jumlah_tot = $point_jumlah_s;

                } 

                // ================== mengambil data poin minggu =============

                 // bulan ini
                 $mount = date("m");

                 // tangal hari ini
                 $hari_ini = date("Y-m-d");
                                
                 // mengecek tanggal
                 $hari_bulan = date('j');

                 $bulan_start = $mount;

                 $tahun_start = date("Y");


                 for ($i=1; $i <= 8; $i++) { 
                 $hari_pada_bulan =  $tahun_start."-".$bulan_start."-0".$i;

                 // echo "====== </br>";

                 // echo $hari_pada_bulan; echo "<-- hari yang diperiksa </br>";
                 
                     $date=date_create($hari_pada_bulan);

                 $variabel_sabtu = date_format($date,"N"); 

                 // echo  $variabel_sabtu; echo "<-- angka sabtu </br>"; 

                 $tanggal_sabtu_pertama = $i;    

                    if ($variabel_sabtu == 6) {
                        $hari_akhir = $hari_pada_bulan;

                        // echo  $hari_akhir; echo "<-- angka hari akhir </br> ====== "; 

                        $i = 8;
                    }
                  }

                // jika tanggal hari ini berada diantara tanggal 01 dan sabu pertama
                    // maka tanggal akhir adalah sabut pertama
                    // jika tidak rumus dialihkan

                if ($hari_bulan <= $tanggal_sabtu_pertama) {

                    // awal minggu pertama pada satu bulan adalah tanggal 01
                    $bulan_start = date("m");
                    $tahun_start = date("Y");
                    $hari_pertama =  $tahun_start."-".$bulan_start."-01";
                    $hari_akhir;
                
                } else {

                    // akhir dan pertengahan bulan
                    $hari_akhir = date("Y-m-d");
                    // echo $hari_ini." <-- hari ini </br>";

                    $nomer_hari = date('N');
                    // echo $nomer_hari." <-- nomer hari </br>";

                    $kurang_1 = $nomer_hari - 1 ;
                    $jumlah_hari =  $kurang_1." days";

                    $date = date_create($hari_ini);
                    date_sub($date,date_interval_create_from_date_string($jumlah_hari));
                    $hari_pertama = date_format($date,"Y-m-d");

                }

                // echo "</br>";
                // echo $hari_awal; echo "<-- hari awal </br>";
                // echo $hari_ini; echo "<-- hari ini </br>";
                
            //   echo $hari_senin."<-- hari senin adalah </br>";
            //   $ess = date('W',strtotime(date("Y-m-01")));
            //   echo $ess."</br>";

                $query_point = mysql_query ("SELECT * FROM transactions 
                    WHERE user_id = '$user_id' 
                    AND transaction_date BETWEEN '$hari_pertama' AND '$hari_akhir'");

                // echo var_dump($query_point)."<-- </br>";

                $point_jumlah_tot_w_z = 0;
                while ($baris_point_w = mysql_fetch_array($query_point)) {

                $id_trans = $baris_point_w['transaction_id'];

                // echo var_dump($id_trans);
                // echo $id_trans."<-- </br>";
                // echo "--- </br>";

                $mengakses_jumlah_barang = mysql_query ("SELECT * FROM transactions_amount WHERE transaction_id = '$id_trans'");

                    $point_perproduk_tot_w = 0;
                    while ($baris_jumlah_barang = mysql_fetch_array($mengakses_jumlah_barang)) {
                        $tr_amount_ = $baris_jumlah_barang['transaction_amount'];
                        $tr_amount_prod_id = $baris_jumlah_barang['product_id'];

                        // echo $tr_amount_." <-- jumlah barang </br>";
                        $mengakses_point_barang = mysql_query ("SELECT * FROM products WHERE product_id = '$tr_amount_prod_id'");
                        $baris_point_barang = mysql_fetch_array($mengakses_point_barang);
                        $product_point_ = $baris_point_barang['product_point'];

                        // echo $product_point_." <-- point barang </br>";
                        $point_perproduk = $tr_amount_ * $product_point_;

                        // echo $point_perproduk." <-- jumlah x point </br>";

                      $point_perproduk_w = $point_perproduk_tot_w + $point_perproduk;
                      $point_perproduk_tot_w = $point_perproduk_w;

                    }

                $point_jumlah_s_w = $point_jumlah_tot_w_z + $point_perproduk_tot_w;
                $point_jumlah_tot_w_z = $point_jumlah_s_w;

                } 

                if (true == empty($point_jumlah_tot_w_z)) {
                     $point_jumlah_tot_w_z = 0;
                } 

                // ================== mengambil data poin bulan ============ 

                $bagianWhere_w = "user_id = '$user_id'  
                AND month(transaction_date)='$mount'
                ";
                $nama_barang_query_m = mysql_query ("SELECT 

                transactions.transaction_id, 
                transactions.transaction_date, 
                transactions.user_id, 
                transactions.customer_id, 
                transactions.shipping_name, 
                transactions.shipping_fee, 
                transactions.total_price, 
                transactions.payment, 
                transactions.receipt_number, 
                transactions.transaction_status,

                transactions_amount.transactions_amount_id, 
                transactions_amount.transaction_id, 
                transactions_amount.product_id, 
                transactions_amount.transaction_amount,

                products.product_id, 
                products.product_title_general, 
                products.product_title_for_recap, 
                products.product_initial_for_label, 
                products.product_base_price, 
                products.product_weight, 
                products.product_point, 
                products.product_status, 
                products.product_amount

               FROM transactions JOIN transactions_amount ON transactions.transaction_id = transactions_amount.transaction_id RIGHT JOIN products ON transactions_amount.product_id = products.product_id WHERE ".$bagianWhere_w);

                $point_jumlah_tot_m = 0;

                while ($baris_nama_barang_m = mysql_fetch_array($nama_barang_query_m)) {

                $amo_id_m = $baris_nama_barang_m['transaction_amount'];
                $point_id_m = $baris_nama_barang_m['product_point'];

                $point_jumlah_m = $amo_id_m * $point_id_m;

                $point_jumlah_s_m = $point_jumlah_tot_m + $point_jumlah_m;
                $point_jumlah_tot_m = $point_jumlah_s_m;

                } 

                if (true == empty($point_jumlah_tot_m)) {
                    $point_jumlah_tot_m = 0;
                }         

                // ================== mengambil conversion perhari =========

                if ($leads_amount_d == 0) {

                    if ($point_jumlah_tot != 0) {
                        $conversion_hari_1 = 100;
                    } else {
                        $conversion_hari_1 = 0;
                    }

                } else {
                    $conversion_hari = ($point_jumlah_tot * 100 )/ $leads_amount_d; 
                    $conversion_hari_1 = number_format ($conversion_hari,0);
                }

                // ================== mengambil conversion minggu ==========

                if ($leads_amount_w_tot == 0) {

                    if ($point_jumlah_tot_w_z != 0) {
                        $conversion_week_1 = 100;
                    } else {
                        $conversion_week_1 = 0;
                    }

                } else {
                    $conversion_week = ($point_jumlah_tot_w_z * 100 )/ $leads_amount_w_tot; 
                    $conversion_week_1 = number_format ($conversion_week,0);
                }

                // ================== mengambil conversion perbulan ========

                if ($leads_amount_m_tot == 0) {

                    if ($point_jumlah_tot_m != 0) {
                        $conversion_mount_1 = 100;
                    } else {
                        $conversion_mount_1 = 0;
                    }

                } else {
                    $conversion_mount = ($point_jumlah_tot_m * 100 )/ $leads_amount_m_tot; 
                    $conversion_mount_1 = number_format ($conversion_mount,0);
                }

                // ==========================================================

                echo "<tr>";
                echo "<td data-hide='hone,tablet'  class='text-center' style='background-color: #01B050; color: #000;'><b>".$user_name."</b></td>";
                // ==== LEADS
                echo "<td data-hide='hone,tablet'  class='text-center'  style='background-color: #8DB4E2; color: #000;'>".$leads_amount_d."</td>";
                $leads_d_jum = $leads_amount_d_jum + $leads_amount_d;
                $leads_amount_d_jum = $leads_d_jum;

                echo "<td data-hide='hone,tablet'  class='text-center' style='background-color: #92D050; color: #000;'>".$leads_amount_w_tot."</td>";

                $leads_amount_w_jum_m = $leads_amount_w_jum + $leads_amount_w_tot;
                $leads_amount_w_jum = $leads_amount_w_jum_m;

                unset($leads_amount_w_tot);

                echo "<td data-hide='hone,tablet' class='text-center' style='background-color: #FFFF01; color: #000;'>".$leads_amount_m_tot."</td>";
                $leads_m_jum_m = $leads_m_jum + $leads_amount_m_tot;
                $leads_m_jum = $leads_m_jum_m;
                unset($leads_amount_m_tot);

                // ==== POINT
                echo "<td data-hide='hone,tablet' class='text-center'  style='background-color: #8DB4E2; color: #000;'>".$point_jumlah_tot."</td>";
                $point_jumlah_tot_d = $point_jumlah_tot_jum + $point_jumlah_tot;
                $point_jumlah_tot_jum = $point_jumlah_tot_d;

                echo "<td data-hide='hone,tablet' class='text-center' style='background-color: #92D050; color: #000;'> ".$point_jumlah_tot_w_z." </td>";
                $point_jum_tot_w_m = $point_jum_tot_w + $point_jumlah_tot_w_z;
                $point_jum_tot_w = $point_jum_tot_w_m;
                unset($point_jumlah_tot_w_z);

                echo "<td data-hide='hone,tablet' class='text-center' style='background-color: #FFFF01; color: #000;'>".$point_jumlah_tot_m."</td>";
                $point_jum_m = $point_jum_ + $point_jumlah_tot_m;
                $point_jum_ = $point_jum_m;

                // ==== CONVERSION
                echo "<td data-hide='hone,tablet' class='text-center'  style='background-color: #8DB4E2; color: #000;'>";
                echo $conversion_hari_1;

                // ================== mengambil conversion perhari =========

                 $conversion_hari_1_m = $conversion_hari_1_jum + $conversion_hari_1;
                 $conversion_hari_1_jum = $conversion_hari_1_m;
                echo "</td>";

                echo "<td data-hide='hone,tablet'  class='text-center' style='background-color: #92D050; color: #000;'> ".$conversion_week_1." </td>";
                 $conversion_week_1_m = $conversion_week_1_jum + $conversion_week_1;
                 $conversion_week_1_jum = $conversion_week_1_m;

                echo "<td data-hide='hone,tablet'  class='text-center'  style='background-color: #FFFF01; color: #000;'>";
                echo $conversion_mount_1;
                // $conversion_mount_1_m = $conversion_mount_1_jum + $conversion_mount_1;
                // $conversion_mount_1_jum = $conversion_mount_1_m;
                echo "</td>";

                echo "</tr>";
                unset($leads_amount);
                unset($point_jumlah_s);

                }
                ?>
                
                </tbody>

                <tfoot>

                <?php 

                echo "<tr  style='background-color: #E6B8B7; color: #000;'><b>";
                echo "<td data-hide='hone,tablet' class='text-center' > JUMLAH </td>";

                echo "<td data-hide='hone,tablet' class='text-center'> ".$leads_amount_d_jum." </td>";
                echo "<td data-hide='hone,tablet' class='text-center'> ".$leads_amount_w_jum." </td>";
                echo "<td data-hide='hone,tablet' class='text-center'> ".$leads_m_jum." </td>";

                echo "<td data-hide='hone,tablet' class='text-center'> ".$point_jumlah_tot_d." </td>";
                echo "<td data-hide='hone,tablet' class='text-center'> ".$point_jum_tot_w." </td>";
                echo "<td data-hide='hone,tablet' class='text-center'> ";
                echo $point_jum_m;
                echo " </td>";     

                echo "<td data-hide='hone,tablet' class='text-center'> ";

                if ($leads_amount_d_jum == 0) {

                    if ($point_jumlah_tot_d != 0) {
                        $conversion_hari_1 = 100;
                    } else {
                        $conversion_hari_1 = 0;
                    }

                } else {
                    $conversion_hari = ($point_jumlah_tot_d * 100 )/ $leads_amount_d_jum; 
                    $conversion_hari_1 = number_format ($conversion_hari,0);
                }

                echo $conversion_hari_1;

                echo "</td>";
                echo "<td data-hide='hone,tablet' class='text-center'> ";

                if ($leads_amount_w_jum == 0) {

                    if ($leads_amount_w_jum != 0) {
                        $conversion_week_1_jum = 100;
                    } else {
                        $conversion_week_1_jum = 0;
                    }

                } else {
                    $conversion_week_1 = ($point_jum_tot_w * 100 )/ $leads_amount_w_jum; 
                    $conversion_week_1_jum = number_format ($conversion_week_1,0);
                }

                echo $conversion_week_1_jum;
                echo " </td>";
                echo "<td data-hide='hone,tablet' class='text-center'> ";

                if ($leads_m_jum == 0) {

                    if ($leads_m_jum != 0) {
                        $conversion_mount_1_jum = 100;
                    } else {
                        $conversion_mount_1_jum = 0;
                    }

                } else {
                    $conversion_mount_1 = ($point_jum_m * 100 )/ $leads_m_jum; 
                    $conversion_mount_1_jum = number_format ($conversion_mount_1,0);
                }

                echo $conversion_mount_1_jum;

                echo " </td>";

                echo "</b></tr>";


                ?> 


                </tfoot>
            </table>
        </div>
<!-- TABEL KEDUA -->

        </div><!-- /.panel-body -->
        </div><!-- /.panel -->

        </div>

        <div class="col-md-3">
                        
        </div>
        </div>

        </div>
        </section>

    </body>
</html>
