<?php 

	include ('config.php');

	$id_cs        = $_POST['id_cs'];
	$image        = $_POST['image'];

	class emp{}

	if (empty($id_cs)){

		$response = new emp();
		$response->success = 0;
		$response->message = "Kolom Tidak Boleh Kosong";
		die(json_encode($response));
	}
	else{
	    
	    $random = random_word(20);
		
		$path = "images/".$random.".png";
		
		// sesuiakan ip address laptop/pc atau URL server
		$actualpath = "http://api.drimhos.com/MANAJEMEN/$path";

		$query = mysql_query("UPDATE users SET 
								user_picture    = '$actualpath'
								WHERE user_id   = '$id_cs' 
							");
		if ($query) {
		    file_put_contents($path,base64_decode($image));
		    
			$response = new emp();
			$response->success = 1;
			$response->message = "Data Profil Berhasil di Update";
			die(json_encode($response));
		}
		else{
			$response = new emp();
			$response->success = 0;
			$response->message = "Data Profil Gagal di Update";
			die(json_encode($response));
		}

	}
	
	// fungsi random string pada gambar untuk menghindari nama file yang sama
	function random_word($id = 20){
		$pool = '1234567890abcdefghijkmnpqrstuvwxyz';
		
		$word = '';
		for ($i = 0; $i < $id; $i++){
			$word .= substr($pool, mt_rand(0, strlen($pool) -1), 1);
		}
		return $word; 
	}

?>