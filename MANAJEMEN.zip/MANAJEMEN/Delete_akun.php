<?php 
	
	include ('config.php');

	$id_akun   = $_POST['id_akun'];
	
	class emp{}
	
	if (empty($id_akun)) { 
		$response = new emp();
		$response->success = 0;
		$response->message = "1. Data Tidak Terhapus: ".$id_akun; 
		die(json_encode($response));
	} else {
		$query = mysql_query("DELETE FROM users WHERE user_id = '$id_akun'");
		
		if ($query) {
			$response = new emp();
			$response->success = 1;
			$response->message = "Data Akun Berhasil di Hapus";
			die(json_encode($response));
		} else{ 
			$response = new emp();
			$response->success = 0;
			$response->message = "Data Tidak Terhapus";
			die(json_encode($response)); 
		}	
	}

?>