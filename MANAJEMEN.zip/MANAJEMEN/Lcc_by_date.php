<?php 
   
    include('config.php');
    
    $tglMulai = $_POST['tglMulai'];
    $tglAkhir = $_POST['tglAkhir'];
    
	$cs = mysql_query("SELECT * FROM users WHERE rule_user='costumer servis' ORDER BY user_name ASC");
	$total = mysql_num_rows($cs);

	$data  = array();
	while ($row1 = mysql_fetch_assoc($cs)) {
		$data[] = $row1['user_id'];
	}

    
    $json  = array();
    for($i=0; $i < $total; $i++){
        
        $user_id = $data[$i];
        
        $queryM = mysql_query ("SELECT SUM(leads_amount) AS leadsM FROM leads WHERE user_id = '$user_id' AND leads_date BETWEEN '$tglMulai' AND '$tglAkhir'");
        $data_m = mysql_fetch_array($queryM);
        
        $tot_leadsM = $data_m['leadsM'];
        
        if(empty($tot_leadsM)){
            $totM = "0";
        }
        else{
            $totM = $tot_leadsM;
        }
        
        $cs_cek = mysql_query("SELECT * FROM users WHERE rule_user='costumer servis' AND user_id = '$user_id' ORDER BY user_name ASC");
	    $data_cs = mysql_fetch_array($cs_cek);
	    $nama = $data_cs['user_name'];
        
        //------------------------ Closing -----------------
        $nama_barang_query_m = mysql_query("SELECT * FROM transactions INNER JOIN transactions_amount ON transactions.transaction_id = transactions_amount.transaction_id INNER JOIN products ON transactions_amount.product_id = products.product_id WHERE transactions.user_id = '$user_id' AND transaction_date BETWEEN '$tglMulai' AND '$tglAkhir' ");
        $jml_total_m = mysql_num_rows($nama_barang_query_m);
        
        $poin_total_closing_m = 0;
        
        for($k=0; $k < $jml_total_m; $k++){
            $data_closing_m = mysql_fetch_array($nama_barang_query_m);
            
            $jumlah_m = $data_closing_m['transaction_amount'];
            $poin_m   = $data_closing_m['product_point'];
            
            $poin_jmlh_m = $jumlah_m * $poin_m;
            
            $poin_total_closing_m = $poin_total_closing_m + $poin_jmlh_m;
        }
        //------------------------ Closing -----------------
        
        // ================== mengambil conversion =========
        if ($totM == 0) {

            if ($poin_total_closing_m != 0) {
                $conversion_hari_1 = 100;
            } else {
                $conversion_hari_1 = "0";
            }

        } else {
            $conversion_hari = ($poin_total_closing_m * 100 )/ $totM; 
            $conversion_hari_1 = number_format ($conversion_hari,0);
        }
        // ================== mengambil conversion =========
        
        
        $row = array(user_id=>$user_id, user_name=>$nama, leads=>$totM, closing=>$poin_total_closing_m, conversion=>$conversion_hari_1);
        $json[] = $row;
    
    }
    
    echo json_encode($json);
    mysql_close($connect);

?>