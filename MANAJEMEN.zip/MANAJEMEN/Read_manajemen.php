<?php 
	
	include ('config.php');

	$id_manajemen = $_POST['id_manajemen'];

	class emp{}

	if (empty($id_manajemen)) {
		$response = new emp();
		$response->success = 0;
		$response->message = "Error Mengambil Data";
		die(json_encode($response));
	}
	else{

		$query = mysql_query("SELECT * FROM users WHERE user_id ='$id_manajemen' ");
		$row   = mysql_fetch_array($query);
		
		$query1 = mysql_query("SELECT * FROM users WHERE rule_user='costumer servis'");
		
		$query2 = mysql_query("SELECT * FROM costumers");
		$query3 = mysql_query("SELECT * FROM transactions");

		if (!empty($row)) {
		 	$response = new emp();
		 	$response->success = 1;
		 	$response->user_id     	     = $row['user_id'];
		 	$response->user_name    	 = $row['user_name'];
		 	$response->user_nickname 	 = $row['user_nickname'];
		 	$response->user_phone_number = $row['user_phone_number'];
		 	$response->user_email 	     = $row['user_email'];
		 	$response->	password_hash	 = $row['password_hash'];
		 	$response->user_picture      = $row['user_picture'];
		 	$response->jml_akun          = mysql_num_rows($query1);
		 	$response->jml_pelanggan     = mysql_num_rows($query2);
		 	$response->jml_transaksi     = mysql_num_rows($query3);
		 	die(json_encode($response));
		 }
		 else{
		 	$response = new emp();
		 	$response->success = 0;
		 	$response->message = "Error Mengambil Data";
		 	die(json_encode($response));
		 } 

	}

?>