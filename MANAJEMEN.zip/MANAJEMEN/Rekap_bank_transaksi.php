<?php 

	include('config.php');

 
        
        $tglAwal 	= $_POST['tglAwal'];
    	$tglAkhir 	= $_POST['tglAkhir'];
        $namaCs     = $_POST['namaCs'];
        $namaPlg    = $_POST['namaPlg'];
        
        if($namaPlg == 'Pilih Semua'){
            $query =mysql_query("SELECT payment, SUM(total_price) AS tot_price FROM transactions WHERE user_id = '$namaCs' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir' GROUP BY transactions.payment");
    
        	$json  = array();
        	while ($row = mysql_fetch_assoc($query)) {
        		$json[] = $row;
        	}
        	echo json_encode($json);
        	mysql_close($connect);
        }
        else{
            $query =mysql_query("SELECT payment, SUM(total_price) AS tot_price FROM transactions WHERE user_id = '$namaCs' AND customer_id = '$namaPlg' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir' GROUP BY transactions.payment");
    
        	$json  = array();
        	while ($row = mysql_fetch_assoc($query)) {
        		$json[] = $row;
        	}
        	echo json_encode($json);
        	mysql_close($connect);
        }
        
?>