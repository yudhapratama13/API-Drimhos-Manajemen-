<?php 
    include('config.php');

    $date_today = date("Y-m-d");
    
	$cs = mysql_query("SELECT * FROM users WHERE rule_user='costumer servis' ORDER BY user_name ASC");
	$total = mysql_num_rows($cs);

	$data  = array();
	while ($row1 = mysql_fetch_assoc($cs)) {
		$data[] = $row1['user_id'];
	}
	
	//-------------------------------------------------------------------------
	
	            $date_today = date("Y-m-d");
	
	            // bulan ini
                 $mount = date("m");
                 // tangal hari ini
                 $hari_ini = date("Y-m-d");               
                 // mengecek tanggal
                 $hari_bulan = date('j');
                 $bulan_start = $mount;
                 $tahun_start = date("Y");

                 for ($i=1; $i <= 8; $i++) { 
                 $hari_pada_bulan =  $tahun_start."-".$bulan_start."-0".$i;

                 // echo "</br><b>".$hari_pada_bulan."</b></br>";

                 // echo "====== </br>";
                 // echo $hari_pada_bulan; echo "<-- hari yang diperiksa </br>";
                 
                 $date = date_create($hari_pada_bulan);
                 $variabel_sabtu = date_format($date,"N"); 

                 // echo  $variabel_sabtu; echo "<-- angka sabtu </br>"; 
                 $tanggal_sabtu_pertama = $i;    

                    if ($variabel_sabtu == 6) {
                        $hari_akhir = $hari_pada_bulan;

                        // echo  $hari_akhir; echo "<-- angka hari akhir </br> ====== "; 
                        $i = 8;
                    }
                  }

                // jika tanggal hari ini berada diantara tanggal 01 dan sabu pertama
                // maka tanggal akhir adalah sabut pertama
                // jika tidak rumus dialihkan

                  // echo $hari_bulan."<-- tanggal har ini </br>";
                  // echo $tanggal_sabtu_pertama."<-- tanggal har ini </br></br>";


                if ($hari_bulan <= $tanggal_sabtu_pertama) {

                    // awal minggu pertama pada satu bulan adalah tanggal 01
                    $bulan_start = date("m");
                    $tahun_start = date("Y");
                    $hari_pertama =  $tahun_start."-".$bulan_start."-01";
                    $hari_akhir;

                    // echo " hari pertaman tanggal 01";
                
                } else {

                    // akhir dan pertengahan bulan
                    $hari_akhir = date("Y-m-d");
                    // echo $hari_ini." <-- hari ini </br>";

                    $nomer_hari = date('N');
                    // echo $nomer_hari." <-- nomer hari </br>";

                    $kurang_1 = $nomer_hari - 1 ;
                    $jumlah_hari =  $kurang_1." days";

                    $date = date_create($hari_ini);
                    date_sub($date,date_interval_create_from_date_string($jumlah_hari));
                    $hari_pertama = date_format($date,"Y-m-d");

                }
                
    //-------------------------------------------------------------------------
    
    $json  = array();
    for($i=0; $i < $total; $i++){
        
        $user_id = $data[$i];
        
        //---------------------------------
        
        //-------- Closing Harian ---------
        $nama_barang_query = mysql_query("SELECT * FROM transactions INNER JOIN transactions_amount ON transactions.transaction_id = transactions_amount.transaction_id INNER JOIN products ON transactions_amount.product_id = products.product_id WHERE transactions.user_id = '$user_id' AND transaction_date = '$date_today' ");
        $jml_total = mysql_num_rows($nama_barang_query);
        
        $poin_total_closing_h = 0;
        
        for($j=0; $j < $jml_total; $j++){
            $data_closing_h = mysql_fetch_array($nama_barang_query);
            
            $jumlah = $data_closing_h['transaction_amount'];
            $poin   = $data_closing_h['product_point'];
            
            $poin_jmlh_h = $jumlah * $poin;
            
            $poin_total_closing_h = $poin_total_closing_h + $poin_jmlh_h;
        }
        //-------- Closing Harian ---------
        
        //-------- Closing Mingguan ---------
        $nama_barang_query_m = mysql_query("SELECT * FROM transactions INNER JOIN transactions_amount ON transactions.transaction_id = transactions_amount.transaction_id INNER JOIN products ON transactions_amount.product_id = products.product_id WHERE transactions.user_id = '$user_id' AND transaction_date BETWEEN '$hari_pertama' AND '$hari_akhir' ");
        $jml_total_m = mysql_num_rows($nama_barang_query_m);
        
        $poin_total_closing_m = 0;
        
        for($k=0; $k < $jml_total_m; $k++){
            $data_closing_m = mysql_fetch_array($nama_barang_query_m);
            
            $jumlah_m = $data_closing_m['transaction_amount'];
            $poin_m   = $data_closing_m['product_point'];
            
            $poin_jmlh_m = $jumlah_m * $poin_m;
            
            $poin_total_closing_m = $poin_total_closing_m + $poin_jmlh_m;
        }
        //-------- Closing Mingguan ---------
        
        //-------- Closing Bulanan ---------
        $nama_barang_query_t = mysql_query("SELECT * FROM transactions INNER JOIN transactions_amount ON transactions.transaction_id = transactions_amount.transaction_id INNER JOIN products ON transactions_amount.product_id = products.product_id WHERE transactions.user_id = '$user_id' AND month(transaction_date)='$mount' ");
        $jml_total_t = mysql_num_rows($nama_barang_query_t);
        
        $poin_total_closing_t = 0;
        
        for($l=0; $l < $jml_total_t; $l++){
            $data_closing_t = mysql_fetch_array($nama_barang_query_t);
            
            $jumlah_t = $data_closing_t['transaction_amount'];
            $poin_t   = $data_closing_t['product_point'];
            
            $poin_jmlh_t = $jumlah_t * $poin_t;
            
            $poin_total_closing_t = $poin_total_closing_t + $poin_jmlh_t;
        }
        //-------- Closing Bulanan ---------
        
        
        if(empty($jml_total)){
            $totClosing_h = $poin_total_closing_h;
        }
        else{
            $totClosing_h = $poin_total_closing_h;
        }
        
        if(empty($jml_total_m)){
            $totClosing_m = $poin_total_closing_m;
        }
        else{
            $totClosing_m = $poin_total_closing_m;
        }
        
        //---------------------------------
        
        $cs_cek = mysql_query("SELECT * FROM users WHERE rule_user='costumer servis' AND user_id = '$user_id' ORDER BY user_name ASC");
	    $data_cs = mysql_fetch_array($cs_cek);
	    $nama = $data_cs['user_name'];
        
        $row = array(user_id=>$user_id, user_name=>$nama, closing_hari=>$poin_total_closing_h, closing_minggu=>$poin_total_closing_m, closing_bulan=>$poin_total_closing_t);
        $json[] = $row;
    
    }
    
    echo json_encode($json);
    mysql_close($connect);

?>