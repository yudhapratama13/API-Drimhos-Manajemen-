<?php 

	include ('config.php');

	$transaksi_id     = $_POST['transaksi_id'];
	$jam_transaksi    = date('h:i:sa');
	$tgl_transaksi    = $_POST['tgl_transaksi'];
	$nama_pelanggan   = $_POST['nama_pelanggan'];
	$nama_pengiriman  = $_POST['nama_pengiriman'];
	$biaya_kirim      = $_POST['biaya_kirim'];
	$total_bayar      = $_POST['total_bayar'];
	$nama_pembayaran  = $_POST['nama_pembayaran'];
	$no_resi          = $_POST['no_resi'];
	$transaksi_status = $_POST['transaksi_status'];

	class emp{}

		if (empty($transaksi_id)) {
			$response = new emp();
			$response->success = 0;
			$response->message = "Id Transaksi Kosong";
			die(json_encode($response));
		}
		else{

            $pelanggan = mysql_query("SELECT * FROM costumers WHERE costumer_name = '$nama_pelanggan' ");
            $data  = mysql_fetch_array($pelanggan);
            $id_cs = $data['costumer_id'];
            
			$query = mysql_query("UPDATE transactions SET transaction_time = '$jam_transaksi', transaction_date = '$tgl_transaksi', customer_id = '$id_cs', shipping_name = '$nama_pengiriman', shipping_fee = '$biaya_kirim', total_price = '$total_bayar', payment = '$nama_pembayaran', receipt_number = '$no_resi', 	transaction_status = '$transaksi_status' WHERE transaction_id = '$transaksi_id' ");

			if ($query) {
				$response = new emp();
				$response->success = 1;
				$response->message = "Transaksi Berhasil di Update";
				die(json_encode($response));
			}
			else{
				$response = new emp();
				$response->success = 0;
				$response->message = "Transaksi Gagal di Update";
				die(json_encode($response));
			}

		}

?>