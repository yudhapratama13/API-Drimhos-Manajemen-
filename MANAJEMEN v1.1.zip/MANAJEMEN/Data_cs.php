<?php 

	include('config.php');

	$query = mysql_query("SELECT * FROM users WHERE rule_user='costumer servis' ORDER BY user_name ASC");
	
	$result = array();
	
	while($row = mysql_fetch_assoc($query)){
		array_push($result,array(
			'user_name'=>$row['user_name'],
			'user_id'  =>$row['user_id']
		));
	}
	
	echo json_encode(array('result'=>$result));
	
	mysql_close($connect);

?>