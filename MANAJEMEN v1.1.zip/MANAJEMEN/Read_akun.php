<?php 

	include('config.php');

	$query = mysql_query("SELECT * FROM users WHERE rule_user='costumer servis' ORDER BY user_name ASC");
	$json  = array();
	while ($row = mysql_fetch_assoc($query)) {
		$json[] = $row;
	}
	echo json_encode($json);
	mysql_close($connect);

?>