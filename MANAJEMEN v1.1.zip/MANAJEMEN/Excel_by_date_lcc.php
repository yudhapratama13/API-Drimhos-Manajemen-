<?php

include('Config_lcc_daily_excel.php');

    $end = $_GET['endDate'];
    $start = $_GET['startDate'];

   $filename = "recap_LCC_".$start."_sd_".$end.".xml";
  header('Content-type: application/ms-excel');
  header('Content-Disposition: attachment; filename='.$filename);

?>

<!DOCTYPE html>

<html lang="en"> 
    <!--/ END SIDEBAR LEFT -->
        <!-- START @PAGE CONTENT -->
            <section id="page-content">
                <!-- Start body content -->
                <div class="body-content animated fadeIn">

                    <div id="tour-12" class="row">
                    </div>

                    <!-- /.row -->
                    <div class="row">
                    <div class="col-md-12">
                    <div class="table-responsive rounded mb-20">

                </div>
                </div>
                
                <div class="col-md-10">
                <div class="panel-body">
                
                <?php
                    echo "<h4> LCC dari tanggal : ".$start." s/d ".$end."</h4>";
                ?>
                </div>
                    <div class="panel-body">

                <table id="datatable-dom" class="table table-striped table-lilac" border="1px" bordercolor="black" >
                <thead>
                <tr>
                    <th data-hide="phone,tablet"  class="text-center" style="background-color: #01B050; color: #000;"> Nama CS</th>
                    <th data-hide="phone,tablet"  class="text-center" style="background-color: #C0504D; color: #000;"> LEADS </th>
                    <th data-hide="phone,tablet"  class="text-center" style="background-color: #F79646; color: #000;"> CLOSING (POIN) </th>
                    <th data-hide="phone,tablet"  class="text-center" style="background-color: #FF0101; color: #000;"> CONVERSION </th>
                </tr>
                </thead>

                <tbody>
                
            <?php

            $leads_amount_d_jum = 0;
            $point_jumlah_tot_jum = 0;
            $conversion_hari_1_jum = 0;

            $query_user = mysql_query("SELECT * FROM users WHERE rule_user = 'costumer servis'");

            while ($baris_user = mysql_fetch_array($query_user)) {

                $user_id = $baris_user['user_id'];
                $user_name = $baris_user['user_name'];
                
                // ==== mengakses leads
                $query_leads = mysql_query("SELECT * FROM leads WHERE user_id = '$user_id' AND leads_date BETWEEN '$start' AND '$end'");

                    $leads_amount_d = 0;

                    while ($baris_leads = mysql_fetch_array($query_leads)) {
                        $le_amount_d = $baris_leads['leads_amount'];

                        $le_jum_s = $leads_amount_d + $le_amount_d;
                        $leads_amount_d = $le_jum_s;
                    }

                    if (true == empty($leads_amount_d)) {
                        $leads_amount_d = 0;
                    } 

                // ==== mengakses point
                // $bagianWhere_w = " transaction_date BETWEEN '$start' AND '$end'";
                $jumlah_transaksi_query = mysql_query ("SELECT * FROM transactions 
                    WHERE user_id = '$user_id' AND transaction_date BETWEEN '$start' AND '$end'");

                $point_jumlah_tot = 0;
                while ($baris_transaksi_query = mysql_fetch_array($jumlah_transaksi_query)) {

                    $trans_id = $baris_transaksi_query['transaction_id'];

                    // echo var_dump($trans_id); echo "</br>";

                    $mengakses_transaksi_query = mysql_query ("SELECT * FROM transactions_amount WHERE transaction_id = '$trans_id'");

                    $point_jumlah_tot_perorang = 0;
                    while ($baris_point_barang = mysql_fetch_array($mengakses_transaksi_query)) {

                        $tr_amount_ = $baris_point_barang['transaction_amount'];
                        $tr_amount_prod_id = $baris_point_barang['product_id'];

                        // echo $tr_amount_." <-- jumlah barang </br>";
                        $mengakses_point_barang = mysql_query ("SELECT * FROM products WHERE product_id = '$tr_amount_prod_id'");
                        $baris_point_barang = mysql_fetch_array($mengakses_point_barang);
                        $product_point_ = $baris_point_barang['product_point'];

                        // echo $product_point_." <-- point barang </br>";
                        $point_perproduk = $tr_amount_ * $product_point_; 

                        // echo "jumlah barang = ".$tr_amount_." x poin barang = " .$product_point_; 
                        // echo "</br>";
                        // echo $point_perproduk; 
                        // echo " jumlah poin per produk </br>";
                        // echo "</br>";

                        $point_jumlah_s = $point_jumlah_tot_perorang + $point_perproduk;
                        $point_jumlah_tot_perorang = $point_jumlah_s;
                    }

                    $point_jumlah_s_perorang = $point_jumlah_tot + $point_jumlah_tot_perorang;
                    $point_jumlah_tot = $point_jumlah_s_perorang;

                //    echo $point_jumlah_tot; echo " jumlah poin total </br>";
                //    echo "------ </br>";

                }
                    // unset($point_perproduk);
                    // ====
                    if ($leads_amount_d == 0) {

                        if ($point_jumlah_tot != 0) {
                            $conversion_hari_1 = 100;
                        } else {
                            $conversion_hari_1 = 0;
                        }

                    } else {
                        $conversion_hari = ($point_jumlah_tot * 100 )/ $leads_amount_d; 
                        $conversion_hari_1 = number_format ($conversion_hari,0);
                    }

                    echo "<tr>";

                    echo "<td data-hide='hone,tablet'  class='text-center'  style='background-color: #01B050; color: #000;'><b>".$user_name."</b></td>";

                    echo "<td data-hide='hone,tablet'  class='text-center' style='background-color: #FFFF01; color: #000;'>";
                    echo $leads_amount_d;
                    echo "</td>";
                    // ====
                     $leads_d_jum = $leads_amount_d_jum + $leads_amount_d;
                     $leads_amount_d_jum = $leads_d_jum;
                    // ====
                    
                    echo "<td data-hide='hone,tablet'  class='text-center' style='background-color: #FFFF01; color: #000;'>";
                    echo $point_jumlah_tot;

                    echo "</td>";
                    // ====
                    $point_jumlah_tot_d = $point_jumlah_tot_jum + $point_jumlah_tot;
                    $point_jumlah_tot_jum = $point_jumlah_tot_d;
                    // ====

                    echo "<td data-hide='hone,tablet'  class='text-center' style='background-color: #FFFF01; color: #000;'>";
                    echo $conversion_hari_1;
                    // ====

                    if ($leads_amount_d_jum == 0) {

                        if ($point_jumlah_tot_jum != 0) {
                            $conversion_hari_1_jum = 100;
                        } else {
                            $conversion_hari_1_jum = 0;
                        }

                    } else {
                        $conversion_hari_1 = ($point_jumlah_tot_jum * 100 )/ $leads_amount_d_jum; 
                        $conversion_hari_1_jum = number_format ($conversion_hari_1,0);
                    }

                    // $conversion_hari_1_m = $conversion_hari_1_jum + $conversion_hari_1;
                    // $conversion_hari_1_jum = $conversion_hari_1_m;
                    // ====

                    echo "</td>";

                echo "</tr>";

                unset($leads_amount);
                unset($point_jumlah_tot);
            }

            ?>

                
                </tbody>

                <tfoot>
                    <tr style='background-color: #FFFF01; color: #000;'>
                        <th data-hide="phone,tablet"  class="text-center" > Total </th>
                        <th data-hide="phone,tablet"  class="text-center" > 
                        <?php echo $leads_amount_d_jum; ?> 
                        </th>
                        <th data-hide="phone,tablet"  class="text-center" >
                            <?php echo $point_jumlah_tot_jum; ?>
                        </th>
                        <th data-hide="phone,tablet"  class="text-center" > 
                        <?php echo $conversion_hari_1_jum; ?>
                        </th>
                    </tr>
                </tfoot>

                </table>

                </div>
                </div>

                </div>
                </div>
            </section>

        </section><!-- /#wrapper -->
        <!--/ END WRAPPER -->
        
    </body>
    <!--/ END BODY -->
</html>
