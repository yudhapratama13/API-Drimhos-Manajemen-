<?php 

	include('config.php');

	class emp{}

	if (!$_POST['transaksi_id'] || !$_POST['nama_produk'] || !$_POST['jumlah_produk'] ) {
		$response = new emp();
		$response->success = 0;
		$response->message = 'Kolom Tidak Boleh Kosong';
		die(json_encode($response));
	}
	else{

		$transaksi_id     = $_POST['transaksi_id'];
		$nama_produk 	  = $_POST['nama_produk'];
		$jumlah_produk    = $_POST['jumlah_produk'];

		$cek_barang = mysql_query("SELECT * FROM products WHERE product_title_general = '$nama_produk'");
		$barang 	= mysql_fetch_array($cek_barang);
		$id_barang  = $barang['product_id'];

		$transaksi_amount = mysql_query("INSERT INTO transactions_amount VALUES ('', '$transaksi_id', '$id_barang', '$jumlah_produk')");

		if ($transaksi_amount) {
			$response = new emp();
			$response->success = 1;
			$response->message = 'Transaksi Berhasil di Update';
			die(json_encode($response));
		}
		else{
			$response = new emp();
			$response->success = 0;
			$response->message = 'Transaksi Gagal di Update';
			die(json_encode($response));
		}
	}

?>