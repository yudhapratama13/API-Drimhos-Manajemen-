<?php 

	include('config.php');

    	$tglAwal 	= $_POST['tglAwal'];
    	$tglAkhir 	= $_POST['tglAkhir'];
        $namaCs     = $_POST['namaCs'];
      
        $query =mysql_query("SELECT product_title_for_recap, SUM(transaction_amount) AS total, product_point FROM transactions INNER JOIN transactions_amount ON transactions_amount.transaction_id = transactions.transaction_id INNER JOIN products ON products.product_id = transactions_amount.product_id WHERE transactions.user_id = '$namaCs' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir' GROUP BY transactions_amount.product_id ORDER BY transactions.transaction_id ASC");
    
    	$json  = array();
    	while ($row = mysql_fetch_assoc($query)) {
    		$json[] = $row;
    	}
    	echo json_encode($json);
    	mysql_close($connect);    
        
       
        
?>