<?php 
    
	if ($_GET['status_manajemen'] == 'STO 1') {
		$server			= 'localhost';
		$user 			= 'drimhosc_sto2';
		$password 		= 'S4ndySTO2';
		$databaseName 	= 'drimhosc_sto1';	
	}
	elseif ($_GET['status_manajemen'] == 'STO 2') {
		$server			= 'localhost';
		$user 			= 'drimhosc_sto2';
		$password 		= 'S4ndySTO2';
		$databaseName 	= 'drimhosc_sto2';
	}
	elseif ($_GET['status_manajemen'] == 'STO 3') {
		$server			= 'localhost';
		$user 			= 'drimhosc_sto2';
		$password 		= 'S4ndySTO2';
		$databaseName 	= 'drimhosc_sto3';
	}
	elseif ($_GET['status_manajemen'] == 'STO 4') {
		$server			= 'localhost';
		$user 			= 'drimhosc_sto2';
		$password 		= 'S4ndySTO2';
		$databaseName 	= 'drimhosc_sto4';
	}
	elseif ($_GET['status_manajemen'] == 'STO 5') {
		$server			= 'localhost';
		$user 			= 'drimhosc_sto2';
		$password 		= 'S4ndySTO2';
		$databaseName 	= 'drimhosc_sto5';
	}
	elseif ($_GET['status_manajemen'] == 'STO 6') {
		$server			= 'localhost';
		$user 			= 'drimhosc_sto2';
		$password 		= 'S4ndySTO2';
		$databaseName 	= 'drimhosc_sto6';
	}
	elseif ($_GET['status_manajemen'] == 'STO 7') {
		$server			= 'localhost';
		$user 			= 'drimhosc_sto2';
		$password 		= 'S4ndySTO2';
		$databaseName 	= 'drimhosc_to7';
	}
	elseif ($_GET['status_manajemen'] == 'STO 8') {
		$server			= 'localhost';
		$user 			= 'drimhosc_sto2';
		$password 		= 'S4ndySTO2';
		$databaseName 	= 'drimhosc_to8';
	}
	elseif ($_GET['status_manajemen'] == 'STO 9') {
		$server			= 'localhost';
		$user 			= 'drimhosc_sto2';
		$password 		= 'S4ndySTO2';
		$databaseName 	= 'drimhosc_srto9';
	}
	elseif ($_GET['status_manajemen'] == 'STO 10') {
		$server			= 'localhost';
		$user 			= 'drimhosc_sto2';
		$password 		= 'S4ndySTO2';
		$databaseName 	= 'drimhosc_to10';
	}
	elseif ($_POST['status_manajemen'] == 'STO 11') {
		$server			= 'localhost';
		$user 			= 'drimhosc_sto2';
		$password 		= 'S4ndySTO2';
		$databaseName 	= 'drimhosc_to11';
	}
	elseif ($_GET['status_manajemen'] == 'STO 12') {
		$server			= 'localhost';
		$user 			= 'drimhosc_sto2';
		$password 		= 'S4ndySTO2';
		$databaseName 	= 'drimhosc_to12';
	}
	elseif ($_GET['status_manajemen'] == 'STO 13') {
		$server			= 'localhost';
		$user 			= 'drimhosc_sto2';
		$password 		= 'S4ndySTO2';
		$databaseName 	= 'drimhosc_to13';
	}
	elseif ($_GET['status_manajemen'] == 'STO 14') {
		$server			= 'localhost';
		$user 			= 'drimhosc_sto2';
		$password 		= 'S4ndySTO2';
		$databaseName 	= 'drimhosc_to14';
	}
	elseif ($_GET['status_manajemen'] == 'STO 15') {
		$server			= 'localhost';
		$user 			= 'drimhosc_sto2';
		$password 		= 'S4ndySTO2';
		$databaseName 	= 'drimhosc_to15';
	}
	elseif ($_GET['status_manajemen'] == 'STO 16') {
		$server			= 'localhost';
		$user 			= 'drimhosc_sto2';
		$password 		= 'S4ndySTO2';
		$databaseName 	= 'drimhosc_to16';
	}
	elseif ($_GET['status_manajemen'] == 'STO 17') {
		$server			= 'localhost';
		$user 			= 'drimhosc_sto2';
		$password 		= 'S4ndySTO2';
		$databaseName 	= 'drimhosc_to17';
	}
	elseif ($_GET['status_manajemen'] == 'STO 18') {
		$server			= 'localhost';
		$user 			= 'drimhosc_sto2';
		$password 		= 'S4ndySTO2';
		$databaseName 	= 'drimhosc_to18';
	}
	elseif ($_GET['status_manajemen'] == 'STO 19') {
		$server			= 'localhost';
		$user 			= 'drimhosc_sto2';
		$password 		= 'S4ndySTO2';
		$databaseName 	= 'drimhosc_to19';
	}
	elseif ($_GET['status_manajemen'] == 'STO 22') {
		$server			= 'localhost';
		$user 			= 'drimhosc_sto2';
		$password 		= 'S4ndySTO2';
		$databaseName 	= 'drimhosc_to22';
	}
	elseif ($_GET['status_manajemen'] == 'STO 23') {
		$server			= 'localhost';
		$user 			= 'drimhosc_sto2';
		$password 		= 'S4ndySTO2';
		$databaseName 	= 'drimhosc_to23';
	}
	else{
		//$server			= 'localhost';
		//$user 			= 'drimhosc_sto2';
		//$password 		= 'S4ndySTO2';
		//$databaseName 	= 'drimhosc_to10';
		
	}

	$connect 		= mysql_connect($server, $user, $password) or die('Koneksi Gagal');
	mysql_select_db($databaseName) or die('Database Belum Siap');

?>