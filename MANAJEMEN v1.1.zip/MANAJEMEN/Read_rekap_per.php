<?php 

	include('config.php');

    	$tglAwal 	= $_POST['tglAwal'];
    	$tglAkhir 	= $_POST['tglAkhir'];
        $namaPlg    = $_POST['namaPlg'];
        $namaCs     = $_POST['namaCs'];
        
        if($namaPlg == 'Pilih Semua' && $namaCs == 'Pilih Semua'){
            $query =mysql_query("SELECT users.user_id, user_name, COALESCE(SUM(total_price)) AS total_bayar FROM transactions INNER JOIN users ON users.user_id = transactions.user_id WHERE transaction_date BETWEEN '$tglAwal' AND '$tglAkhir' GROUP BY transactions.user_id ORDER BY transactions.transaction_id ASC");
        
        	$json  = array();
        	while ($row = mysql_fetch_assoc($query)) {
        		$json[] = $row;
        	}
        	echo json_encode($json);
        	mysql_close($connect);    
        }
        else if($namaCs == 'Pilih Semua' && $namaPlg != 'Pilih Semua'){
            
            $query =mysql_query("SELECT users.user_id, user_name, COALESCE(SUM(total_price)) AS total_bayar FROM transactions INNER JOIN users ON users.user_id = transactions.user_id WHERE transactions.customer_id = '$namaPlg' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir' GROUP BY transactions.user_id ORDER BY transactions.transaction_id ASC");
        
        	$json  = array();
        	while ($row = mysql_fetch_assoc($query)) {
        		$json[] = $row;
        	}
        	echo json_encode($json);
        	mysql_close($connect);
        }
        else if($namaPlg == 'Pilih Semua' && $namaCs != 'Pilih Semua'){
            
            $query =mysql_query("SELECT users.user_id, user_name, COALESCE(SUM(total_price)) AS total_bayar FROM transactions INNER JOIN users ON users.user_id = transactions.user_id WHERE transactions.user_id = '$namaCs' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir' GROUP BY transactions.user_id ORDER BY transactions.transaction_id ASC");
        
        	$json  = array();
        	while ($row = mysql_fetch_assoc($query)) {
        		$json[] = $row;
        	}
        	echo json_encode($json);
        	mysql_close($connect);
        }
        else{
            
            $query =mysql_query("SELECT users.user_id, user_name, COALESCE(SUM(total_price)) AS total_bayar FROM transactions INNER JOIN users ON users.user_id = transactions.user_id WHERE transactions.user_id = '$namaCs' AND transactions.customer_id = '$namaPlg' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir' GROUP BY transactions.user_id ORDER BY transactions.transaction_id ASC");
        
        	$json  = array();
        	while ($row = mysql_fetch_assoc($query)) {
        		$json[] = $row;
        	}
        	echo json_encode($json);
        	mysql_close($connect);
            
        }
        
?>