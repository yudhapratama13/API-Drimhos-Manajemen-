<?php 

	include('config.php');

	$query = mysql_query("SELECT * FROM costumers ORDER BY costumer_id DESC");
	
	$result = array();
	
	while($row = mysql_fetch_assoc($query)){
		array_push($result,array(
			'costumer_name'=>$row['costumer_name'],
			'costumer_address'=>$row['costumer_address'],
			'costumer_sub_district'=>$row['costumer_sub_district'],
			'costumer_district'=>$row['costumer_district'],
			'costumer_province'=>$row['costumer_province'],
			'costumer_postal_code'=>$row['costumer_postal_code'],
			'costumer_phone_number'=>$row['costumer_phone_number']
		));
	}
	
	echo json_encode(array('result'=>$result));
	
	mysql_close($connect);

?>