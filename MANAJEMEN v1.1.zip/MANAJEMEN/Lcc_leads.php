<?php 
   include('config.php');

    $date_today = date("Y-m-d");
    
	$cs = mysql_query("SELECT * FROM users WHERE rule_user='costumer servis' ORDER BY user_name ASC");
	$total = mysql_num_rows($cs);

	$data  = array();
	while ($row1 = mysql_fetch_assoc($cs)) {
		$data[] = $row1['user_id'];
	}
	
	//-------------------------------------------------------------------------
	
	            // bulan ini
                 $mount = date("m");
                 // tangal hari ini
                 $hari_ini = date("Y-m-d");               
                 // mengecek tanggal
                 $hari_bulan = date('j');
                 $bulan_start = $mount;
                 $tahun_start = date("Y");

                 for ($i=1; $i <= 8; $i++) { 
                 $hari_pada_bulan =  $tahun_start."-".$bulan_start."-0".$i;

                 // echo "</br><b>".$hari_pada_bulan."</b></br>";

                 // echo "====== </br>";
                 // echo $hari_pada_bulan; echo "<-- hari yang diperiksa </br>";
                 
                 $date = date_create($hari_pada_bulan);
                 $variabel_sabtu = date_format($date,"N"); 

                 // echo  $variabel_sabtu; echo "<-- angka sabtu </br>"; 
                 $tanggal_sabtu_pertama = $i;    

                    if ($variabel_sabtu == 6) {
                        $hari_akhir = $hari_pada_bulan;

                        // echo  $hari_akhir; echo "<-- angka hari akhir </br> ====== "; 
                        $i = 8;
                    }
                  }

                // jika tanggal hari ini berada diantara tanggal 01 dan sabu pertama
                // maka tanggal akhir adalah sabut pertama
                // jika tidak rumus dialihkan

                  // echo $hari_bulan."<-- tanggal har ini </br>";
                  // echo $tanggal_sabtu_pertama."<-- tanggal har ini </br></br>";


                if ($hari_bulan <= $tanggal_sabtu_pertama) {

                    // awal minggu pertama pada satu bulan adalah tanggal 01
                    $bulan_start = date("m");
                    $tahun_start = date("Y");
                    $hari_pertama =  $tahun_start."-".$bulan_start."-01";
                    $hari_akhir;

                    // echo " hari pertaman tanggal 01";
                
                } else {

                    // akhir dan pertengahan bulan
                    $hari_akhir = date("Y-m-d");
                    // echo $hari_ini." <-- hari ini </br>";

                    $nomer_hari = date('N');
                    // echo $nomer_hari." <-- nomer hari </br>";

                    $kurang_1 = $nomer_hari - 1 ;
                    $jumlah_hari =  $kurang_1." days";

                    $date = date_create($hari_ini);
                    date_sub($date,date_interval_create_from_date_string($jumlah_hari));
                    $hari_pertama = date_format($date,"Y-m-d");

                }
                
    //-------------------------------------------------------------------------
    
    $json  = array();
    for($i=0; $i < $total; $i++){
        
        $user_id = $data[$i];
        
        $query = mysql_query("SELECT users.user_id, user_name, leads_amount FROM leads RIGHT JOIN users ON users.user_id = leads.user_id WHERE users.user_id = '$user_id' AND leads_date = '$date_today'");
        
        $queryM = mysql_query ("SELECT SUM(leads_amount) AS leadsM FROM leads WHERE user_id = '$user_id' AND leads_date BETWEEN '$hari_pertama' AND '$hari_akhir'");
        $data_m = mysql_fetch_array($queryM);
        
        $tot_leadsM = $data_m['leadsM'];
        
        $queryT = mysql_query("SELECT SUM(leads_amount) AS leadsT FROM leads WHERE user_id = '$user_id' AND month(leads_date)='$mount'");
        $data_t = mysql_fetch_array($queryT);
        
        $tot_leadsT = $data_t['leadsT'];
        
        if(empty($tot_leadsM)){
            $totM = "0";
        }
        else{
            $totM = $tot_leadsM;
        }
        
        if(empty($tot_leadsT)){
            $totT = "0";
        }
        else{
            $totT = $tot_leadsT;
        }
        
        if(mysql_num_rows($query) < 1){
            $cs_cek = mysql_query("SELECT * FROM users WHERE rule_user='costumer servis' AND user_id = '$user_id' ORDER BY user_name ASC");
    	    $data_cs = mysql_fetch_array($cs_cek);
    	    $nama = $data_cs['user_name'];
            $leads_amount = "0";
            
            
        }
        else{
            while ($row = mysql_fetch_assoc($query)) {
                $nama = $row['user_name'];
                $leads_amount = $row['leads_amount'];
    	    }
        }
        
        $row = array(user_id=>$user_id, user_name=>$nama, leads_amount=>$leads_amount, leads_minggu=>$totM, leads_bulan=>$totT);
        $json[] = $row;
    
    }
    
    echo json_encode($json);
    mysql_close($connect);

?>