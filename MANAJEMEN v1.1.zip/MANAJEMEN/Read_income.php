<?php 
	
	include ('config.php');

	$tglAwal 	= $_POST['tglAwal'];
	$tglAkhir 	= $_POST['tglAkhir'];
    $namaPlg    = $_POST['namaPlg'];
    $namaCs     = $_POST['namaCs'];

	class emp{}
	
	if($namaPlg == 'Pilih Semua' && $namaCs == 'Pilih Semua'){
	    $query_bri = mysql_query("SELECT COALESCE(SUM(total_price), 0) AS total FROM transactions WHERE payment = 'bri' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir'");
	    $bri = mysql_fetch_array($query_bri);
	    
	    $query_bni = mysql_query("SELECT COALESCE(SUM(total_price), 0) AS total FROM transactions WHERE payment = 'bni' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir'");
	    $bni = mysql_fetch_array($query_bni);
	    
	    $query_mandiri = mysql_query("SELECT COALESCE(SUM(total_price), 0) AS total FROM transactions WHERE payment = 'mandiri' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir'");
	    $mandiri = mysql_fetch_array($query_mandiri);
	    
	    $query_bca = mysql_query("SELECT COALESCE(SUM(total_price), 0) AS total FROM transactions WHERE payment = 'bca' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir'");
	    $bca = mysql_fetch_array($query_bca);
	    
	    $query_cash = mysql_query("SELECT COALESCE(SUM(total_price), 0) AS total FROM transactions WHERE payment = 'cash' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir'");
	    $cash = mysql_fetch_array($query_cash);
	    
	}
	
	else if($namaCs == 'Pilih Semua' && $namaPlg != 'Pilih Semua'){
	     $query_bri = mysql_query("SELECT COALESCE(SUM(total_price), 0) AS total FROM transactions WHERE customer_id = '$namaPlg' AND payment = 'bri' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir'");
	    $bri = mysql_fetch_array($query_bri);
	    
	    $query_bni = mysql_query("SELECT COALESCE(SUM(total_price), 0) AS total FROM transactions WHERE customer_id = '$namaPlg' AND payment = 'bni' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir'");
	    $bni = mysql_fetch_array($query_bni);
	    
	    $query_mandiri = mysql_query("SELECT COALESCE(SUM(total_price), 0) AS total FROM transactions WHERE customer_id = '$namaPlg' AND payment = 'mandiri' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir'");
	    $mandiri = mysql_fetch_array($query_mandiri);
	    
	    $query_bca = mysql_query("SELECT COALESCE(SUM(total_price), 0) AS total FROM transactions WHERE customer_id = '$namaPlg' AND payment = 'bca' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir'");
	    $bca = mysql_fetch_array($query_bca);
	    
	    $query_cash = mysql_query("SELECT COALESCE(SUM(total_price), 0) AS total FROM transactions WHERE customer_id = '$namaPlg' AND payment = 'cash' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir'");
	    $cash = mysql_fetch_array($query_cash);
	}
	
	else if($namaPlg == 'Pilih Semua' && $namaCs != 'Pilih Semua'){
	    $query_bri = mysql_query("SELECT COALESCE(SUM(total_price), 0) AS total FROM transactions WHERE user_id = '$namaCs' AND payment = 'bri' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir'");
	    $bri = mysql_fetch_array($query_bri);
	    
	    $query_bni = mysql_query("SELECT COALESCE(SUM(total_price), 0) AS total FROM transactions WHERE user_id = '$namaCs' AND payment = 'bni' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir'");
	    $bni = mysql_fetch_array($query_bni);
	    
	    $query_mandiri = mysql_query("SELECT COALESCE(SUM(total_price), 0) AS total FROM transactions WHERE user_id = '$namaCs' AND payment = 'mandiri' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir'");
	    $mandiri = mysql_fetch_array($query_mandiri);
	    
	    $query_bca = mysql_query("SELECT COALESCE(SUM(total_price), 0) AS total FROM transactions WHERE user_id = '$namaCs' AND payment = 'bca' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir'");
	    $bca = mysql_fetch_array($query_bca);
	    
	    $query_cash = mysql_query("SELECT COALESCE(SUM(total_price), 0) AS total FROM transactions WHERE user_id = '$namaCs' AND payment = 'cash' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir'");
	    $cash = mysql_fetch_array($query_cash);
	}
	else{
	     $query_bri = mysql_query("SELECT COALESCE(SUM(total_price), 0) AS total FROM transactions WHERE user_id = '$namaCs' AND customer_id = '$namaPlg' AND payment = 'bri' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir'");
	    $bri = mysql_fetch_array($query_bri);
	    
	    $query_bni = mysql_query("SELECT COALESCE(SUM(total_price), 0) AS total FROM transactions WHERE user_id = '$namaCs' AND  customer_id = '$namaPlg' AND customer_id = '$namaPlg' AND payment = 'bni' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir'");
	    $bni = mysql_fetch_array($query_bni);
	    
	    $query_mandiri = mysql_query("SELECT COALESCE(SUM(total_price), 0) AS total FROM transactions WHERE user_id = '$namaCs' AND customer_id = '$namaPlg' AND customer_id = '$namaPlg' AND payment = 'mandiri' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir'");
	    $mandiri = mysql_fetch_array($query_mandiri);
	    
	    $query_bca = mysql_query("SELECT COALESCE(SUM(total_price), 0) AS total FROM transactions WHERE user_id = '$namaCs' AND customer_id = '$namaPlg' AND customer_id = '$namaPlg' AND payment = 'bca' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir'");
	    $bca = mysql_fetch_array($query_bca);
	    
	    $query_cash = mysql_query("SELECT COALESCE(SUM(total_price), 0) AS total FROM transactions WHERE user_id = '$namaCs' AND customer_id = '$namaPlg' AND customer_id = '$namaPlg' AND payment = 'cash' AND transaction_date BETWEEN '$tglAwal' AND '$tglAkhir'");
	    $cash = mysql_fetch_array($query_cash);
	}

	if ($query_bri) {
	 	$response = new emp();
	 	$response->success = 1;
	 	$response->bri     	 = $bri['total'];
	 	$response->bni     	 = $bni['total'];
	 	$response->mandiri   = $mandiri['total'];
	 	$response->bca       = $bca['total'];
	 	$response->cash      = $cash['total'];
	 	die(json_encode($response));
	 }
	 else{
	 	$response = new emp();
	 	$response->success = 0;
	 	$response->message = "Error Mengambil Data";
	 	die(json_encode($response));
	 } 

?>