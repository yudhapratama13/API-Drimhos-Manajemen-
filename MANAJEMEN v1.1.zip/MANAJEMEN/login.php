<?php 

	include('config.php');

	class usr{}

	$username 	= $_POST['username'];
	$password 	= $_POST['password'];

	if (empty($username) || empty($password)) {
		$response = new usr();
		$response->success = 0;
		$response->message = "Kolom tidak boleh kosong";
		die(json_encode($response));
	}

	$query = mysql_query("SELECT * FROM users WHERE user_email='$username' AND password_hash='$password' AND rule_user='manajemen' ");

	$row   = mysql_fetch_array($query);

	if (!empty($row)) {
		$response = new usr();
		$response->success = 1;
		$response->message = "Selamat Datang ".$row['user_name']; 
		$response->id      = $row['user_id'];
		$response->username= $row['user_name'];
		$response->user_picture = $row['user_picture'];
		die(json_encode($response));
	}
	else{
		$response = new usr();
		$response->success = 0;
		$response->message = "Username, Password atau Status Manajemen Salah";
		die(json_encode($response));
	}

	mysql_close($connect);

?>