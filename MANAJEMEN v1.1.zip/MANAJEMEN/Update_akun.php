<?php 

	include ('config.php');

	$id_akun   = $_POST['id_akun'];

	$nama_lengkap   = $_POST['nama_lengkap'];
	$nama_panggilan = $_POST['nama_panggilan'];
	$no_tlp 		= $_POST['no_tlp'];
	$email 		    = $_POST['email'];
	$password 		= $_POST['password'];

	class emp{}

	if (empty($nama_lengkap) || empty($nama_panggilan) || empty($no_tlp) || empty($email) || empty($password)){

		$response = new emp();
		$response->success = 0;
		$response->message = "Kolom Tidak Boleh Kosong";
		die(json_encode($response));
	}
	else{

		$query = mysql_query("UPDATE users SET 
								user_name 			= '$nama_lengkap', 
								user_nickname 		= '$nama_panggilan',
								user_phone_number 	= '$no_tlp',
								user_email 		    = '$email',
								password_hash 		= '$password'
								WHERE user_id 		= '$id_akun' 
							");
		if ($query) {
			$response = new emp();
			$response->success = 1;
			$response->message = "Data Akun Berhasil di Update";
			die(json_encode($response));
		}
		else{
			$response = new emp();
			$response->success = 0;
			$response->message = "Data Akun Gagal di Update";
			die(json_encode($response));
		}

	}

?>