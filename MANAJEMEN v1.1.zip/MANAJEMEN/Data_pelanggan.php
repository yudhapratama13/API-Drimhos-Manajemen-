<?php 

	include('config.php');

	$query = mysql_query("SELECT * FROM costumers ORDER BY costumer_id DESC");
	
	$result = array();
	
	while($row = mysql_fetch_assoc($query)){
		array_push($result,array(
			'costumer_name'=>$row['costumer_name'],
			'costumer_id'  =>$row['costumer_id']
		));
	}
	
	echo json_encode(array('result'=>$result));
	
	mysql_close($connect);

?>