<?php 
	
	include ('config.php');

	$id_pelanggan = $_POST['id_pelanggan'];

	class emp{}

	if (empty($id_pelanggan)) {
		$response = new emp();
		$response->success = 0;
		$response->message = "Error Mengambil Data";
		die(json_encode($response));
	}
	else{

		$query = mysql_query("SELECT * FROM costumers WHERE costumer_id = '$id_pelanggan' ");
		$row   = mysql_fetch_array($query);

		if (!empty($row)) {
		 	$response = new emp();
		 	$response->success = 1;
		 	$response->costumer_id      	 = $row['costumer_id'];
		 	$response->costumer_name    	 = $row['costumer_name'];
		 	$response->costumer_address 	 = $row['costumer_address'];
		 	$response->costumer_sub_district = $row['costumer_sub_district'];
		 	$response->costumer_district 	 = $row['costumer_district'];
		 	$response->costumer_province	 = $row['costumer_province'];
		 	$response->costumer_postal_code  = $row['costumer_postal_code'];
		 	$response->costumer_phone_number = $row['costumer_phone_number'];
		 	die(json_encode($response));
		 }
		 else{
		 	$response = new emp();
		 	$response->success = 0;
		 	$response->message = "Error Mengambil Data";
		 	die(json_encode($response));
		 } 

	}

?>